require "keybow"

-- Key mappings --

function handle_key_00(pressed)
    keybow.set_key("", pressed)
end

function handle_key_01(pressed)
    keybow.set_key("", pressed)
end

function handle_key_02(pressed)
    keybow.set_key("", pressed)
end

function handle_key_03(pressed)
    keybow.set_key("", pressed)
end

function handle_key_04(pressed)
    keybow.set_key("", pressed)
end

function handle_key_05(pressed)
    keybow.set_key("", pressed)
end

function handle_key_06(pressed)
    keybow.set_key("", pressed)
end

function handle_key_07(pressed)
    keybow.set_key("", pressed)
end

function handle_key_08(pressed)
    keybow.set_key("", pressed)
end

function handle_key_09(pressed)
    keybow.set_key("", pressed)
end

function handle_key_10(pressed)
    keybow.set_key("", pressed)
end

function handle_key_11(pressed)
    keybow.set_key("", pressed)
end
